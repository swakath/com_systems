% Function for 16QAM modulation with/without gray labeling
function modulatedSignal = qam16Modulation(signal, snr, isGrayLabel)
    signalLen = length(signal);
    modulatedSignal = zeros(1, signalLen/4);
    symbols = [3+3i, 1+3i, -1+3i, -3+3i;
               3+1i, 1+1i, -1+1i, -3+1i;
               3-1i, 1-1i, -1-1i, -3-1i;
               3-3i, 1-3i, -1-3i, -3-3i];
           
    bit_combos_gray = ["0 0 0 0", "0 0 0 1", "0 0 1 1", "0 0 1 0";
                       "0 1 0 0", "0 1 0 1", "0 1 1 1", "0 1 1 0";
                       "1 1 0 0", "1 1 0 1", "1 1 1 1", "1 1 1 0";
                       "1 0 0 0", "1 0 0 1", "1 0 1 1", "1 0 1 0"];
                   
    bit_combos_nogray = ["0 0 0 0", "0 0 0 1", "0 0 1 0", "0 0 1 1";
                         "0 1 0 0", "0 1 0 1", "0 1 1 0", "0 1 1 1";
                         "1 0 0 0", "1 0 0 1", "1 0 1 0", "1 0 1 1";
                         "1 1 0 0", "1 1 0 1", "1 1 1 0", "1 1 1 1"];

    if isGrayLabel == 1 % With Gray Labeling
        for i = 1:4:signalLen-3
            % Finding the symbols corresponding to 4 bits at a time
            bits = strjoin(string(signal(i:i+3)));
            indexMat = contains(bit_combos_gray, bits);
            modulatedSignal(ceil(i/4)) = symbols(indexMat);
        end
    elseif isGrayLabel == 0 % Without Gray Labeling
        for i = 1:4:signalLen-3
            % Finding the symbols corresponding to 4 bits at a time
            bits = strjoin(string(signal(i:i+3)));
            indexMat = contains(bit_combos_nogray, bits);
            modulatedSignal(ceil(i/4)) = symbols(indexMat);
        end
    else
        disp('Invalid Input for Gray Labeling. Must be only 0 or 1');
    end
    modulatedSignal = qamAWGN(modulatedSignal,snr);
end