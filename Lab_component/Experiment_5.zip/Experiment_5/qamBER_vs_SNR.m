%% BER CALCULATION WITH GRAY LABELING
% Defining the signal length
signalLen = 10000;

% Defining the number of iterations the signal is tested for each SNR
Itr = 100;

% We define SNR array in dBW
snr = 0:0.2:15;
snrLen = length(snr);
%Vector to store bit error rate corresponding to each SNR value
BER_gray = zeros(1,snrLen);


for i = 1:snrLen
    curBER = 0;
    for j = 1:Itr
        % Generating a random signal with binary bits (0 and 1)
        signal = randi([0,1],1,signalLen);

        % Generating QPSK symbols with gray labeling
        modulatedSignal = qam16Modulation(signal, snr(i),1);
               
        % Demodulation
        demodulatedSignal = qam16Demodulation(modulatedSignal,1);
        
        %error
        error = signal~=demodulatedSignal;
        curBER = curBER+sum(error);
    end
    BER_gray(i) = curBER;
end
% To get the fractional error
BER_gray = BER_gray/(signalLen*Itr);

% Plotting the BER vs. SNR graph
figure(3);
semilogy(snr, BER_gray, '-bo')
title('BER vs. SNR Plot (With Gray Labeling)');
xlabel('SNR (dBW)');
ylabel('BER');
grid on;

%% BER CALCULATION WITHOUT GRAY LABELING

% In this third section we calculate the BER without gray labeling
% We have an error resolution of 10^-7
% Please reduce the number of iterations to get lower run time.

% Defining the signal length
signalLen = 100000;

% Defining the number of iterations the signal is tested for each SNR
Itr = 100;

% We define SNR array in dBW
snr = 0:0.2:15;

%Vector to store bit error rate corresponding to each SNR value
bit_error_nogray = zeros(numel(snr),1);
symbol_error_nogray = zeros(numel(snr),1);

for i = 1:numel(snr)
    
    for j = 1:Itr
        % Generating a random signal with binary bits (0 and 1)
        signal_bits = randi([0,1],signalLen,1);

        % Generating QPSK symbols with gray labeling
        tx_16qam_symbols_nogray = bits_to_16qam(signal_bits.', 0);
        
        % Adding noise and demodulating for each SNR
        noisy_signal_nogray = add_noise(tx_16qam_symbols_nogray, snr(i));
        
        % Demodulation
        demod_signal_nogray = demodulation(noisy_signal_nogray);

        % To get the binary bits corresponding to demodulated symbols
        rx_signal_bits_nogray = qam16_to_bits(demod_signal_nogray, 0);

        % To get a bitwise difference between the tx and rx signal
        bitwise_difference = rx_signal_bits_nogray - signal_bits.';
        symbolwise_diff = demod_signal_nogray - tx_16qam_symbols_nogray;
        
        symbol_error_nogray(i) = symbol_error_nogray(i) + calculate_ber(symbolwise_diff);

        bit_error_nogray(i) = bit_error_nogray(i) + calculate_ber(bitwise_difference);
    end
end

% To get the fractional error
bit_error_nogray = bit_error_nogray/(signalLen*Itr);
symbol_error_nogray = symbol_error_nogray/(signalLen*Itr);

% Plotting the BER vs. SNR graph
figure(4);
semilogy(snr, bit_error_nogray, '-bo')
title('BER vs. SNR Plot (Without Gray Labeling)');
xlabel('SNR (dBW)');
ylabel('BER');
grid on;

%% THEORETICAL GRAPH USING Q-FUNCTION

% In this fourth section we first compute a theoretical curves defining the
% error probability variation with SNR for a 16QAM communication system.
% We then plot the theoretical curves with our practical curves.

% We define signal to noise ratio as:
% SNR = Eb/No

% In our case of 16QAM communication system, we have
% Eb = 5/2
% Also, the textbook defines
% sigma = sqrt(No/2)        (sigma => standard deviation of noise)

% So, we get the relation between sigma and SNR as:
% sigma = sqrt(5/(4*SNR))

% As the calculation of bit error rate is difficult for 16QAM
% We calculate the symbol error rate as follows:
% P_s = 3*Q(sqrt(4*SNR/5)) - (9/4)*[Q(sqrt(4*SNR/5))]^2

symbol_error_theo = zeros(1, numel(snr));
for i = 1:numel(snr)
    qvalue = qfunc(sqrt(4*(10^(snr(i)/10))/5));
    symbol_error_theo(i) = 3*qvalue - (9/4)*qvalue*qvalue;
end

% ########## WITH GRAY LABELING ##########

% We get an approximation for the BER in this case:
% P_e = Q(sqrt(2*SNR))

ber_theo_gray = zeros(1, numel(snr));

% Calculation of theoretical error probability using Q-function
for i = 1:numel(snr)
    ber_theo_gray(i) = qfunc(sqrt(4*(10^(snr(i)/10))));
end

% ########## WITHOUT GRAY LABELING ##########

% We were unable to derive an expression for BER in this case.

figure(5);
semilogy(snr, ber_theo_gray, '-r')
hold on
semilogy(snr, ber_theo_nogray, '-b')
hold off
title('Theoretical BER vs. SNR Plot (With/Without Gray Labeling)');
xlabel('SNR (dBW)');
ylabel('BER');
legend('With Gray Labeling', 'Without Gray Labeling');
legend
grid on;

figure(5);
semilogy(snr, ber_theo_gray, '-rx')
hold on
semilogy(snr, BER_gray, '-bo')
hold off
title('BER vs. SNR Plot (With Gray Labeling)');
xlabel('SNR (dBW)');
ylabel('BER');
legend('Theoretical (Gray Labeling)', 'Practical (Gray Labeling)');
legend
grid on;

figure(6);
semilogy(snr, ber_theo_nogray, '-rx')
hold on
semilogy(snr, bit_error_nogray, '-bo')
hold off
title('BER vs. SNR Plot (Without Gray Labeling)');
xlabel('SNR (dBW)');
ylabel('BER');
legend('Theoretical (No Gray Labeling)', 'Practical (No Gray Labeling)');
legend
grid on;

figure(7);
semilogy(snr, ber_theo_gray, '-rx')
hold on
semilogy(snr, BER_gray, '-co')

semilogy(snr, ber_theo_nogray, '-bx')
semilogy(snr, bit_error_nogray, '-go')
hold off
title('BER vs. SNR Plot (With/Without Gray Labeling, Theoretical and Practical)');
xlabel('SNR (dBW)');
ylabel('BER');
xlim([0 12]);
legend('Theoretical (Gray Labeling)', 'Practical (Gray Labeling)', 'Theoretical (No Gray Labeling)', 'Practical (No Gray Labeling)');
legend
grid on;