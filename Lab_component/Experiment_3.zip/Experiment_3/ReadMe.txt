Name: S U Swakath
Roll No: 180020036

* BER_Graph.jpg is the final graph obtained from the matlab code.
* BER_computation.m is the MATLAB code which computes the theoretical BER and Practical BER using a 1,00,000 length signal and plots the results.
* bpsk_modulation.m is the function that performs BSPK modulation and adds AWGN (using myAWGN function) for a given signal.
* bpsk_demodulation.m is the function that performs BPSK demodulation using ML rule.
* myAWGN.m function adds AWGN of given snr value over a signal.
* Report.pdf contains my report for the current experiment.